

<?php $__env->startSection('content'); ?>
hello
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.faculty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\29Sept_laravel_TTS2\TMS\resources\views/faculty/welcome.blade.php ENDPATH**/ ?>