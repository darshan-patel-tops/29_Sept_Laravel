<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- google icon font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <!-- font awesome icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
    
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <header>
        <div class="container">
            <div class="row justify align-items">
                <div class="col">
                    <?php $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="/storage/<?php echo e($logo->logo); ?>" height="50px" width="50px">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col">
                    <div class="header_text">
                        <ul>
                            
                            <?php $__currentLoopData = $navbars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navbar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(count($navbar->subnavbar) > 0): ?>

                            
                            <li class="dropdown"><a href="<?php echo e($navbar->navbar); ?>"><?php echo e($navbar->navbar); ?><i class="fa-solid fa-caret-down"></i></a>
                                <ul class="dropdown-nav">
                                    <?php $__currentLoopData = $navbar->subnavbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e($sub->subnavbar); ?>"><?php echo e($sub->subnavbar); ?></a></li>
                                    
                                    
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <?php else: ?>
                            
                            <li><a href="<?php echo e($navbar->navbar); ?>"><?php echo e($navbar->navbar); ?></a></li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(auth()->guard()->guest()): ?>
                            
                            
                            <li><a href="login">Login</a></li>
                            <li><a href="registration">Register</a></li>
                            
                            
                            <?php else: ?>
    
                            <li><a href="logout">Logout</a></li>
    
                            <?php endif; ?>
                            
                        </ul>
                    </div>
                </div>
                <div class="col">
                    <div class="number">
                        <ul>
                            <li><a href="#"><i class="fa-solid fa-phone"></i></a></li>
                            <li><a href="#">+91 8905512020</a></li>
                        </ul>

                    </div>
                </div>
            </div>

        </div>
    </header><?php /**PATH C:\xampp\htdocs\laravel\29Sept_laravel_TTS2\TMS\resources\views/layouts/header.blade.php ENDPATH**/ ?>