<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<section class="contact_sec2 mt-10">
    <div class="container mt-10">
        <div class="row mt-10">
            <div class="col_50 mt-10">
                <div class="contact_box mt-10">
                    <div class="contact_box_text mt-10">
                        
                        <h3>registration</h3>


                        <form action="" method="post">
                            <?php echo csrf_field(); ?>

                            <label for="name">name</label>
                            <input type="text" id="name" name="name" placeholder="name">
                            <label for="email"> email</label>
                            <input type="email" id="email" name="email"placeholder="email">
                            <label for="password">password</label>
                            <input type="text" id="password" name="password" placeholder="password">
                

<div class="col-6">
    <button type="submit" class="submit"> Register</button>
</div>

</div>
</div>
</div>
</div>
</div>
</form>

</section>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\allen\resources\views/layouts/registration.blade.php ENDPATH**/ ?>