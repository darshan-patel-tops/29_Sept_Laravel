<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\allen\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>