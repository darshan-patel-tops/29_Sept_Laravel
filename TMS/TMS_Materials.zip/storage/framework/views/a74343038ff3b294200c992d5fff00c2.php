

<?php $__env->startSection('content'); ?>

<div class="col_50">
    <form class="forme_color" action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text" name="course" placeholder="course">
        <input type="text" name="topic"placeholder="topic">
        <input type="file" name="pdf"placeholder="pdf">

       
        <button type="submit">Submit</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.faculty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\29Sept_laravel_TTS2\TMS\resources\views/faculty/upload.blade.php ENDPATH**/ ?>