<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\laravel\29Sept_laravel_TTS2\TMS\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>