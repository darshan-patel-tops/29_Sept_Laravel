<!DOCTYPE html>
<html>
<head>
    <title>Hi</title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($date); ?></p>
    <p><?php echo $data; ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\29Sept_laravel_TTS2\TMS\resources\views/layouts/myPDF.blade.php ENDPATH**/ ?>