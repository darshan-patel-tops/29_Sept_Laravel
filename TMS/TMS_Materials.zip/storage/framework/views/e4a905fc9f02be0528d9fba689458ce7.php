<!DOCTYPE html>
<html>
<head>
    <title>Hi</title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($date); ?></p>
    <p><?php echo $data; ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\allen\resources\views/layouts/myPDF.blade.php ENDPATH**/ ?>