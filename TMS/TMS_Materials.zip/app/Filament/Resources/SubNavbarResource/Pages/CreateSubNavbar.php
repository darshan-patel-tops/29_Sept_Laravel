<?php

namespace App\Filament\Resources\SubNavbarResource\Pages;

use App\Filament\Resources\SubNavbarResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSubNavbar extends CreateRecord
{
    protected static string $resource = SubNavbarResource::class;
}
