@extends('layouts.faculty')

@section('content')
hello
@endsection